#include "algs.h"
#include "error_types.h"

// TODO: Add the function implementations in here.

// None:

// Flip Even:

// Swap 3:

// Rot and Center 5:
