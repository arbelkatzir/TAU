#include "censor.h"
#include "error_types.h"

int censor_and_encrypt(const char *input_path, const char *output_censored_path,
                       encrypt_t enc_type, const char *blacklist_path) {
  // TODO
  return OK;
}
