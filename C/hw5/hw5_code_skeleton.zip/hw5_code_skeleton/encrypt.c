#include "encrypt.h"
#include "error_types.h"

int encrypt_file(const char *input_file_path, const char *output_file_path,
                 encrypt_t enc_type) {
  // TODO
  return OK;
}

int decrypt_file(const char *input_file_path, const char *output_file_path,
                 encrypt_t enc_type) {
  // TODO
  return OK;
}
